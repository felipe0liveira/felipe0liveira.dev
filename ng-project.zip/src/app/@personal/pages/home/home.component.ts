import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  constructor() {
    document.body.style.background = 'linear-gradient(45deg, rgba(0,0,0,1) 0%, rgba(0,34,65,1) 100%)';
  }

  ngOnInit() {
  }

}
