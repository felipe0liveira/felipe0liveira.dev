import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-personal-outlet',
  templateUrl: './personal-outlet.component.html',
  styleUrls: ['./personal-outlet.component.scss']
})
export class PersonalOutletComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
